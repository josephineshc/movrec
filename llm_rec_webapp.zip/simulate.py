"""
오프라인 시뮬레이션: 가상 사용자로 세 조건을 돌려 조작 점검 지표 비교

  export GEMINI_API_KEY=...
  python simulate.py movies.csv embeddings.npy sim_results.json

가상 사용자 = (선호 영화 5편, 질의). 선호 영화는 제목으로 찾음.
"""
import json
import sys

import numpy as np
import pandas as pd

from recommender import CONDITIONS, Gemini, aeed, aesr, aghd, load_movies, recommend

# 필요하면 더 추가 (RecBench+ 질의 유형 참고: 명시적 조건 / 암묵적 취향)
USERS = [
    (["Inception", "Interstellar", "The Prestige", "Memento", "The Dark Knight"],
     "Something mind-bending with a clever twist"),
    (["The Notebook", "La La Land", "About Time", "Pride & Prejudice", "Her"],
     "A romantic movie for a rainy weekend"),
    (["The Conjuring", "Insidious", "Sinister", "It Follows", "Get Out"],
     "I want a horror movie that isn't just jump scares"),
    (["Toy Story 3", "Up", "Inside Out", "Coco", "Zootopia"],
     "An animated film I can watch with my family"),
    (["Mad Max: Fury Road", "John Wick", "The Raid: Redemption", "Gladiator", "Edge of Tomorrow"],
     "Action movies directed by Christopher Nolan"),
    (["Spotlight", "The Social Network", "Moneyball", "The Big Short", "Zodiac"],
     "A movie based on a true story"),
]


def find_ids(titles, movies):
    ids = []
    for t in titles:
        hit = movies[movies["title"].str.lower() == t.lower()]
        if hit.empty:
            raise ValueError(f"풀에 없는 영화: {t}")
        ids.append(hit.sort_values("year").index[-1])
    return ids


def main(movies_path, emb_path, out_path):
    movies = load_movies(movies_path)
    emb = np.load(emb_path)
    llm = Gemini()

    rows, logs = [], []
    for titles, query in USERS:
        liked = find_ids(titles, movies)
        qv = llm.embed([query], task="RETRIEVAL_QUERY")[0]   # 세 조건이 같은 검색 결과를 쓰도록 1번만
        for cond in CONDITIONS:
            r = recommend(cond, query, liked, movies, emb, llm, query_vec=qv)
            rows.append({"query": query, "condition": cond,
                         "AESR": aesr(r.shown, movies), "AEED": aeed(r.shown, movies),
                         "AGHD": aghd(r.shown, movies), "seconds": r.log["seconds"],
                         "filled": len(r.log.get("filled_from_retrieval", []))})
            logs.append({"condition": cond, "shown": r.shown,
                         "titles": movies.loc[r.shown, "title"].tolist(),
                         **{k: v for k, v in r.log.items() if k != "prompt"}})
            print(f"[{cond:11}] {query[:40]:40} → {', '.join(movies.loc[r.shown, 'title'][:4])}…")

    df = pd.DataFrame(rows)
    print("\n조건별 평균 (원 논문: 감정 다양화 AESR .088 / 다양화 없음 .040)")
    print(df.groupby("condition")[["AESR", "AEED", "AGHD", "seconds", "filled"]].mean().round(3))
    json.dump(logs, open(out_path, "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4])
