"""
experiment.db → 분석용 CSV 3개
  participants.csv : 참가자별 1행 (조건, 질의, 선택, 소요시간, 설문 문항별 점수 + 구성개념 평균)
  item_ratings.csv : 참가자 × 추천 영화 10편 (본 적 있음, 선호 1-5, 요청 일치, LLM 순위, 선택 여부)
  manipulation.csv : 참가자별 AESR / AEED / AGHD

  python export.py
"""
import json
import sqlite3

import pandas as pd

import recommender as R
from questionnaire import ATTENTION, ATTENTION_ANSWER, ITEMS

movies = R.load_movies("movies.csv")
con = sqlite3.connect("experiment.db")
con.row_factory = sqlite3.Row
rows = [dict(r) for r in con.execute("SELECT * FROM participants WHERE finished IS NOT NULL")]

P, I, M = [], [], []
for r in rows:
    shown = json.loads(r["shown"])
    ans = json.loads(r["survey"])
    rec = {"pid": r["pid"], "ext_id": r["ext_id"], "condition": r["condition"], "query": r["query"],
           "choice": r["choice"], "choice_title": movies.loc[r["choice"], "title"],
           "choice_rank": shown.index(r["choice"]) + 1,
           "rec_seconds": r["rec_seconds"], "total_minutes": round((r["finished"] - r["created"]) / 60, 1),
           "attention_ok": ans.get(ATTENTION[0]) == ATTENTION_ANSWER}
    for code, cons, rev, _, _ in ITEMS:
        rec[code] = 8 - ans[code] if rev else ans[code]          # 역문항 변환
    for cons in {it[1] for it in ITEMS}:
        rec[f"{cons}_mean"] = round(sum(rec[it[0]] for it in ITEMS if it[1] == cons)
                                    / sum(1 for it in ITEMS if it[1] == cons), 3)
    P.append(rec)

    log = json.loads(r["rec_log"])
    llm_rank = log.get("llm_top30", shown)
    for x in json.loads(r["ratings"]):
        I.append({"pid": r["pid"], "condition": r["condition"], "movie_id": x["id"],
                  "title": movies.loc[x["id"], "title"], "display_pos": shown.index(x["id"]) + 1,
                  "llm_rank": llm_rank.index(x["id"]) + 1 if x["id"] in llm_rank else None,
                  "seen": x["seen"], "like": x["like"], "fit": x["fit"], "chosen": x["id"] == r["choice"],
                  "filled_from_retrieval": x["id"] in log.get("filled_from_retrieval", [])})
    M.append({"pid": r["pid"], "condition": r["condition"], "AESR": R.aesr(shown, movies),
              "AEED": R.aeed(shown, movies), "AGHD": R.aghd(shown, movies)})

pd.DataFrame(P).to_csv("participants.csv", index=False)
pd.DataFrame(I).to_csv("item_ratings.csv", index=False)
pd.DataFrame(M).to_csv("manipulation.csv", index=False)
print(f"완료한 참가자 {len(P)}명 내보냄")
if P:
    print(pd.DataFrame(P).groupby("condition").size())
