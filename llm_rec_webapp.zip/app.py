"""
실험 웹앱 서버

실행:
  pip install -r requirements.txt
  export GEMINI_API_KEY=...
  uvicorn app:app --port 8000          # → http://localhost:8000

가짜 모드 (임베딩·API 없이 화면 흐름만 시험):
  MOCK=1 uvicorn app:app --port 8000

필요한 파일 (같은 폴더): movies.csv, embeddings.npy, posters/<id>.jpg
응답은 experiment.db (SQLite) 에 저장. 내보내기: python export.py
"""
from __future__ import annotations

import json
import os
import random
import re
import secrets
import sqlite3
import threading
import time
from pathlib import Path

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import recommender as R
from questionnaire import ATTENTION, ITEMS, SCALE_KO

BASE = Path(__file__).parent
DB_PATH = BASE / "experiment.db"
MOCK = os.environ.get("MOCK") == "1"

movies = R.load_movies(BASE / "movies.csv")
_title_lc = movies["title"].str.lower()


# ───────── LLM (진짜 / 가짜) ─────────
class MockLLM:
    """화면 테스트용: 임베딩은 무작위, 순위는 후보 순서 그대로"""
    def embed(self, texts, task):
        return R.normalize(np.random.default_rng(abs(hash(texts[0])) % 2**32).normal(size=(len(texts), 768)))

    def rank_ids(self, prompt):
        time.sleep(1.5)
        ids = re.findall(r"^(tt\d+) \|", prompt, re.M)
        n = int(re.search(r"Select the (\d+)", prompt).group(1))
        return ids[:n]


if MOCK:
    llm = MockLLM()
    emb = R.normalize(np.random.default_rng(0).normal(size=(len(movies), 768)).astype(np.float32))
    print("⚠️  MOCK 모드: 추천 결과는 의미 없음")
else:
    llm = R.Gemini()
    emb = np.load(BASE / "embeddings.npy")
    assert len(emb) == len(movies), "embeddings.npy 행 수가 movies.csv와 다름"


# ───────── DB ─────────
_lock = threading.Lock()


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


with db() as con:
    con.execute("""CREATE TABLE IF NOT EXISTS participants (
        pid TEXT PRIMARY KEY, condition TEXT, created REAL, ext_id TEXT,
        liked TEXT, query TEXT, shown TEXT, rec_log TEXT, rec_seconds REAL,
        choice TEXT, choice_time REAL, ratings TEXT,
        survey_order TEXT, survey TEXT, finished REAL, code TEXT)""")


def update(pid, **fields):
    cols = ", ".join(f"{k}=?" for k in fields)
    with _lock, db() as con:
        cur = con.execute(f"UPDATE participants SET {cols} WHERE pid=?", (*fields.values(), pid))
        if cur.rowcount == 0:
            raise HTTPException(404, "참가자를 찾을 수 없어요")


def get(pid):
    with db() as con:
        row = con.execute("SELECT * FROM participants WHERE pid=?", (pid,)).fetchone()
    if not row:
        raise HTTPException(404, "참가자를 찾을 수 없어요")
    return row


def assign_condition(con) -> str:
    """조건별 인원이 가장 적은 쪽으로 (동률이면 무작위) — 균형 무작위 배정"""
    counts = {c: 0 for c in R.CONDITIONS}
    for row in con.execute("SELECT condition, COUNT(*) n FROM participants GROUP BY condition"):
        counts[row["condition"]] = row["n"]
    least = min(counts.values())
    return random.choice([c for c, n in counts.items() if n == least])


def movie_card(mid):
    m = movies.loc[mid]
    return {"id": mid, "title": m["title"], "year": int(m["year"]),
            "genres": m["genres"], "plot": m["plot"]}


# ───────── API ─────────
app = FastAPI()


class StartIn(BaseModel):
    ext_id: str | None = None      # 모집 플랫폼 참가자 ID (있으면)


@app.post("/api/start")
def start(body: StartIn):
    pid = secrets.token_hex(8)
    with _lock, db() as con:
        cond = assign_condition(con)
        con.execute("INSERT INTO participants (pid, condition, created, ext_id) VALUES (?,?,?,?)",
                    (pid, cond, time.time(), body.ext_id))
    return {"pid": pid}           # 조건은 참가자에게 알려주지 않음


@app.get("/api/search")
def search(q: str):
    q = q.strip().lower()
    if len(q) < 2:
        return []
    hit = movies[_title_lc.str.contains(q, regex=False)]
    hit = hit.assign(_starts=~_title_lc[hit.index].str.startswith(q)).sort_values(["_starts", "year"])
    return [movie_card(m) for m in hit.index[:20]]


class RecIn(BaseModel):
    pid: str
    liked: list[str]
    query: str


@app.post("/api/recommend")
def recommend(body: RecIn):
    row = get(body.pid)
    if row["shown"]:                                  # 새로고침해도 같은 결과
        return {"movies": [movie_card(m) for m in json.loads(row["shown"])]}
    if len(set(body.liked)) != 5 or any(m not in movies.index for m in body.liked):
        raise HTTPException(400, "좋아하는 영화 5편을 골라 주세요")
    if len(body.query.strip()) < 5:
        raise HTTPException(400, "요청을 조금 더 자세히 적어 주세요")

    res = R.recommend(row["condition"], body.query.strip(), body.liked, movies, emb, llm)
    update(body.pid, liked=json.dumps(body.liked), query=body.query.strip(),
           shown=json.dumps(res.shown), rec_log=json.dumps(res.log, ensure_ascii=False),
           rec_seconds=res.log["seconds"])
    return {"movies": [movie_card(m) for m in res.shown]}


class ChoiceIn(BaseModel):
    pid: str
    movie_id: str


@app.post("/api/choice")
def choice(body: ChoiceIn):
    row = get(body.pid)
    if body.movie_id not in json.loads(row["shown"] or "[]"):
        raise HTTPException(400, "추천 목록에 없는 영화예요")
    update(body.pid, choice=body.movie_id, choice_time=time.time())
    return {"ok": True}


class Rating(BaseModel):
    id: str
    seen: bool
    like: int          # 1-5
    fit: bool          # 내 요청에 맞는지


class RatingsIn(BaseModel):
    pid: str
    ratings: list[Rating]


@app.post("/api/ratings")
def ratings(body: RatingsIn):
    row = get(body.pid)
    shown = json.loads(row["shown"] or "[]")
    if sorted(r.id for r in body.ratings) != sorted(shown) or any(not 1 <= r.like <= 5 for r in body.ratings):
        raise HTTPException(400, "모든 영화에 응답해 주세요")
    update(body.pid, ratings=json.dumps([r.model_dump() for r in body.ratings]))
    return {"ok": True}


@app.get("/api/survey")
def survey_items(pid: str):
    row = get(pid)
    if row["survey_order"]:
        order = json.loads(row["survey_order"])
    else:
        order = [it[0] for it in ITEMS]
        random.shuffle(order)
        order.insert(len(order) // 2, ATTENTION[0])     # 중간에 주의 확인 문항
        update(pid, survey_order=json.dumps(order))
    text = {it[0]: it[4] for it in [*ITEMS, ATTENTION]}
    return {"items": [{"code": c, "text": text[c]} for c in order], "scale": SCALE_KO}


class SurveyIn(BaseModel):
    pid: str
    answers: dict[str, int]


@app.post("/api/survey")
def survey(body: SurveyIn):
    row = get(body.pid)
    order = json.loads(row["survey_order"] or "[]")
    if set(body.answers) != set(order) or any(not 1 <= v <= 7 for v in body.answers.values()):
        raise HTTPException(400, "모든 문항에 응답해 주세요")
    code = row["code"] or secrets.token_hex(3).upper()
    update(body.pid, survey=json.dumps(body.answers), finished=time.time(), code=code)
    return {"code": code}


# ───────── 정적 파일 ─────────
@app.get("/poster/{mid}.jpg")
def poster(mid: str):
    p = BASE / "posters" / f"{mid}.jpg"
    if not re.fullmatch(r"tt\d+", mid) or not p.exists():
        raise HTTPException(404)
    return FileResponse(p, headers={"Cache-Control": "public, max-age=86400"})


app.mount("/", StaticFiles(directory=BASE / "static", html=True), name="static")
