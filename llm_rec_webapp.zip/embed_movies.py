"""
7,504편 임베딩을 미리 만들어 저장 (한 번만 실행)

  export GEMINI_API_KEY=...
  python embed_movies.py movies.csv embeddings.npy

- 100편씩 나눠 요청하고, 끝난 부분은 embeddings.npy.partial.npy 에 바로 저장
  → 중간에 멈추거나 끊겨도 다시 실행하면 이어서 진행
- 무료 등급이면 요청 사이에 쉬어 가기:  export EMBED_PAUSE=30   (초)
"""
import os
import sys
import time
from pathlib import Path

import numpy as np

from recommender import Gemini, load_movies, movie_text

CHUNK = 100


def main(movies_path: str, out_path: str) -> None:
    movies = load_movies(movies_path)
    texts = [movie_text(r) for _, r in movies.iterrows()]
    partial = Path(out_path + ".partial.npy")
    pause = float(os.environ.get("EMBED_PAUSE", "0"))

    done = np.load(partial) if partial.exists() else np.zeros((0, 0), dtype=np.float32)
    start = len(done)
    if start:
        print(f"이어서 진행: {start}/{len(texts)}편 완료된 상태")

    llm = Gemini()
    parts = [done] if start else []
    for i in range(start, len(texts), CHUNK):
        vecs = llm.embed(texts[i:i + CHUNK], task="RETRIEVAL_DOCUMENT", batch=CHUNK)
        parts.append(vecs)
        np.save(partial, np.concatenate(parts))
        print(f"  {min(i + CHUNK, len(texts))}/{len(texts)}")
        if pause:
            time.sleep(pause)

    emb = np.concatenate(parts)
    np.save(out_path, emb)
    partial.unlink(missing_ok=True)
    print(f"저장: {out_path} {emb.shape}  (행 순서 = movies.csv 순서)")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
