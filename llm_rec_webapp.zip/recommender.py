"""
LLM 추천 어시스턴트 + 감정 다양화 — 추천 로직

세 조건
  baseline   : Gemini가 후보 150편 중 30편을 순위대로 고름 → 상위 10편
  prompt_div : 같은 후보 150편에서 다양화 지시를 추가해 Gemini가 바로 10편 고름
  emotion_div: baseline의 30편에 Lansman et al. (2025) Table 2 알고리즘 적용 → 10편
               (감정 시그니처 원점수 8차원, 맨해튼 거리)
세 조건 모두 최종 10편은 LLM 순위 순서로 정렬해 보여줌.

API 키는 환경변수 GEMINI_API_KEY 로 넣기 (코드에 직접 쓰지 않기).
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

# ───────── 설정 ─────────
GEN_MODEL = os.environ.get("GEN_MODEL", "gemini-3-flash-preview")  # Gemini 3 Flash
EMBED_MODEL = os.environ.get("EMBED_MODEL", "gemini-embedding-001")
EMBED_DIM = 768
# Gemini 3는 temperature를 기본값(1.0)으로 두라고 권장 → 따로 지정하지 않음
THINKING_LEVEL = os.environ.get("THINKING_LEVEL", "low")  # minimal/low/medium/high (기본 high는 느림)
K_RETRIEVE = 150        # 후보 검색 개수
N_CANDIDATES = 30       # baseline이 고르는 후보 수
N_SHOW = 10             # 화면에 보여줄 수
QUERY_WEIGHT = 0.7      # 검색 시 질의:선호영화 비중 (0.7 : 0.3)
EMOTIONS = ["joy", "trust", "fear", "surprise", "sadness", "disgust", "anger", "anticipation"]


# ───────── 데이터 ─────────
def load_movies(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path).set_index("id", drop=False)


def movie_text(row) -> str:
    """임베딩·LLM 입력에 쓰는 텍스트: 제목(연도) + 장르 + 40단어 줄거리"""
    return f"{row['title']} ({row['year']}) | Genres: {row['genres']} | Plot: {row['plot']}"


# ───────── Gemini 래퍼 ─────────
class Gemini:
    def __init__(self, api_key: str | None = None):
        from google import genai
        from google.genai import types
        self.types = types
        self.client = genai.Client(api_key=api_key or os.environ["GEMINI_API_KEY"])

    def embed(self, texts: list[str], task: str, batch: int = 100) -> np.ndarray:
        out = []
        for i in range(0, len(texts), batch):
            chunk = texts[i:i + batch]
            for attempt in range(5):
                try:
                    res = self.client.models.embed_content(
                        model=EMBED_MODEL, contents=chunk,
                        config=self.types.EmbedContentConfig(task_type=task, output_dimensionality=EMBED_DIM),
                    )
                    out.extend(e.values for e in res.embeddings)
                    break
                except Exception as e:
                    code = getattr(e, "code", None)
                    if code not in (429, 500, 503):      # 속도 제한·서버 오류만 재시도
                        print(f"  embed 오류 ({code}): {e}")
                        raise
                    wait = 2 ** attempt * 15
                    print(f"  embed 재시도 {attempt + 1} ({code}: {str(e)[:200]}), {wait}s 대기")
                    time.sleep(wait)
            else:
                raise RuntimeError("임베딩 실패")
        return normalize(np.array(out, dtype=np.float32))

    def rank_ids(self, prompt: str) -> list[str]:
        res = self.client.models.generate_content(
            model=GEN_MODEL, contents=prompt,
            config=self.types.GenerateContentConfig(
                thinking_config=self.types.ThinkingConfig(thinking_level=THINKING_LEVEL),
                response_mime_type="application/json",
                response_json_schema={"type": "array", "items": {"type": "string"}},
            ),
        )
        return json.loads(res.text)


def normalize(x: np.ndarray) -> np.ndarray:
    return x / np.linalg.norm(x, axis=-1, keepdims=True).clip(1e-12)


# ───────── 1. 후보 검색 ─────────
def retrieve(query_vec: np.ndarray, liked_ids: list[str], movies: pd.DataFrame,
             emb: np.ndarray, k: int = K_RETRIEVE) -> list[str]:
    """질의 임베딩과 선호 영화 평균 임베딩을 섞어 코사인 유사도 상위 k편 (선호 5편 제외)"""
    pos = {mid: i for i, mid in enumerate(movies.index)}
    liked_vec = normalize(emb[[pos[m] for m in liked_ids]].mean(axis=0))
    user_vec = normalize(QUERY_WEIGHT * query_vec + (1 - QUERY_WEIGHT) * liked_vec)
    scores = emb @ user_vec
    scores[[pos[m] for m in liked_ids]] = -np.inf
    top = np.argsort(-scores)[:k]
    return [movies.index[i] for i in top]


# ───────── 2. LLM 프롬프트 ─────────
BASE_PROMPT = """You are a movie recommendation assistant.

The user likes these movies:
{liked}

The user's request:
"{query}"

Candidate movies (ID | title (year) | genres | plot):
{candidates}

Select the {n} candidate movies that best satisfy the user's request and match their taste, \
ranked from most to least recommended.{extra}
Return ONLY a JSON array of {n} movie IDs taken from the candidate list, e.g. ["tt0000001", "tt0000002"]."""

DIVERSIFY_EXTRA = ("\nFollow the user's request, but compose the list of movies that each evoke "
                   "a different mood and emotion.")


def build_prompt(query: str, liked_ids: list[str], cand_ids: list[str],
                 movies: pd.DataFrame, n: int, diversify: bool) -> str:
    liked = "\n".join(f"- {movie_text(movies.loc[m])}" for m in liked_ids)
    cands = "\n".join(f"{m} | {movie_text(movies.loc[m])}" for m in cand_ids)
    return BASE_PROMPT.format(liked=liked, query=query, candidates=cands, n=n,
                              extra=DIVERSIFY_EXTRA if diversify else "")


def ask_llm(llm, prompt: str, cand_ids: list[str], n: int, log: dict) -> list[str]:
    """LLM 응답에서 후보에 있는 ID만, 중복 없이 n개. 모자라면 1회 재시도 후 검색 순서로 채움."""
    valid = set(cand_ids)
    picked: list[str] = []
    for attempt in range(2):
        raw = llm.rank_ids(prompt)
        log.setdefault("raw_responses", []).append(raw)
        for m in raw:
            if m in valid and m not in picked:
                picked.append(m)
        if len(picked) >= n:
            return picked[:n]
    fill = [m for m in cand_ids if m not in picked][: n - len(picked)]
    log["filled_from_retrieval"] = fill          # 분석 때 확인용
    return picked + fill


# ───────── 3. 감정 다양화 (Lansman et al. 2025, Table 2) ─────────
def emotion_vectors(ids: list[str], movies: pd.DataFrame) -> np.ndarray:
    return movies.loc[ids, EMOTIONS].to_numpy(dtype=float)


def diversify(ids: list[str], movies: pd.DataFrame, h: int = N_SHOW) -> list[str]:
    """
    1) 후보 감정 벡터의 중심(평균)에 가장 가까운 영화를 첫 번째로
    2) 이미 고른 영화들과의 맨해튼 거리 합이 가장 큰 영화를 하나씩 추가
    후보 순위(관련도)는 쓰지 않음 — 의사코드 그대로.
    """
    Q = emotion_vectors(ids, movies)
    remaining = list(range(len(ids)))
    centroid = Q.mean(axis=0)
    first = min(remaining, key=lambda i: np.abs(Q[i] - centroid).sum())
    chosen = [first]
    remaining.remove(first)
    while len(chosen) < h and remaining:
        nxt = max(remaining, key=lambda i: np.abs(Q[i] - Q[chosen]).sum())
        chosen.append(nxt)
        remaining.remove(nxt)
    return [ids[i] for i in chosen]


# ───────── 4. 조건별 추천 ─────────
CONDITIONS = ("baseline", "prompt_div", "emotion_div")


@dataclass
class Result:
    condition: str
    shown: list[str]                       # 화면에 보여줄 10편 (LLM 순위 순)
    log: dict = field(default_factory=dict)


def recommend(condition: str, query: str, liked_ids: list[str], movies: pd.DataFrame,
              emb: np.ndarray, llm, query_vec: np.ndarray | None = None) -> Result:
    assert condition in CONDITIONS and len(liked_ids) == 5
    log: dict = {"query": query, "liked": liked_ids, "model": GEN_MODEL, "thinking_level": THINKING_LEVEL}
    t0 = time.time()

    if query_vec is None:
        query_vec = llm.embed([query], task="RETRIEVAL_QUERY")[0]
    cand = retrieve(query_vec, liked_ids, movies, emb)
    log["retrieved"] = cand

    if condition == "prompt_div":
        prompt = build_prompt(query, liked_ids, cand, movies, N_SHOW, diversify=True)
        shown = ask_llm(llm, prompt, cand, N_SHOW, log)
    else:
        prompt = build_prompt(query, liked_ids, cand, movies, N_CANDIDATES, diversify=False)
        top30 = ask_llm(llm, prompt, cand, N_CANDIDATES, log)
        log["llm_top30"] = top30
        if condition == "baseline":
            shown = top30[:N_SHOW]
        else:
            picked = set(diversify(top30, movies))
            shown = [m for m in top30 if m in picked]    # LLM 순위 순으로 재정렬

    log["prompt"] = prompt
    log["seconds"] = round(time.time() - t0, 2)
    return Result(condition, shown, log)


# ───────── 5. 조작 점검 지표 (Lansman et al. Table 5) ─────────
def aesr(ids, movies):
    """Average Emotion Score Range: 감정별 (최댓값-최솟값)의 평균"""
    Q = emotion_vectors(ids, movies)
    return float((Q.max(0) - Q.min(0)).mean())


def aeed(ids, movies):
    """Average Emotions Euclidean Distance: 모든 영화 쌍의 유클리드 거리 평균"""
    Q = emotion_vectors(ids, movies)
    d = [np.linalg.norm(Q[i] - Q[j]) for i in range(len(Q)) for j in range(i + 1, len(Q))]
    return float(np.mean(d))


def aghd(ids, movies):
    """Average Genre Hamming Distance: 장르 멀티핫 벡터의 쌍별 해밍 거리 평균(장르 수로 나눔)"""
    all_g = sorted({g for s in movies["genres"] for g in str(s).split(", ") if g})
    idx = {g: i for i, g in enumerate(all_g)}
    G = np.zeros((len(ids), len(all_g)))
    for r, m in enumerate(ids):
        for g in str(movies.loc[m, "genres"]).split(", "):
            if g:
                G[r, idx[g]] = 1
    d = [np.abs(G[i] - G[j]).sum() / len(all_g) for i in range(len(G)) for j in range(i + 1, len(G))]
    return float(np.mean(d))
